/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grade9;




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Administrator
 */
public class Tester6 {
    public static String S;
    public static String B;
    public static String actionA()
    {
        S="INSERT INTO sixstu (date,username,test_number,students_answers)" +"VALUES (getdate(),'"+main.Login.ID+"','"+main.SelectTest.test+"','A')";
        return S;
    }
    
    public static String actionB()
    {
        S="INSERT INTO sixstu (date,username,test_number,students_answers)" +"VALUES (getdate(),'"+main.Login.ID+"','"+main.SelectTest.test+"','B')";
        return S;
    }
    
    public static String actionC()
    {
        S="INSERT INTO sixstu (date,username,test_number,students_answers)" +"VALUES (getdate(),'"+main.Login.ID+"','"+main.SelectTest.test+"','C')";
        return S;
    }
    
    public static String actionD()
    {
        S="INSERT INTO sixstu (date,username,test_number,students_answers)" +"VALUES (getdate(),'"+main.Login.ID+"','"+main.SelectTest.test+"','D')";
        return S;
    }
    
    public static void OK()
    {
        String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=test9";
	String userName1="sa";
	String userPwd1="abcd1234";
	Connection dbConn1=null;
	Statement sta1=null;
	try
	{                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(S);
	    sta1.close();//关闭数据库�
        }
        catch(Exception e)
        {
            e.printStackTrace();
	    System.out.println("Error!");
        }
        System.out.print(S);
    }
    
    public static float sum_upSQL()
    {
        if(main.SelectTest.test==1)
        {B="SELECT COUNT(*) FROM [test9].[dbo].[six] A, [test9].[dbo].[sixstu] B where (A.ID=B.ID and A.standard_answers1=B.students_answers)";}
        else if(main.SelectTest.test==2)
        {B="SELECT COUNT(*) FROM [test9].[dbo].[six] A, [test9].[dbo].[sixstu] B where (A.ID=B.ID and A.standard_answers2=B.students_answers)";}
        else if(main.SelectTest.test==3)
        {B="SELECT COUNT(*) FROM [test9].[dbo].[six] A, [test9].[dbo].[sixstu] B where (A.ID=B.ID and A.standard_answers3=B.students_answers)";}
        else if(main.SelectTest.test==4)
        {B="SELECT COUNT(*) FROM [test9].[dbo].[six] A, [test9].[dbo].[sixstu] B where (A.ID=B.ID and A.standard_answers4=B.students_answers)";}
        else if(main.SelectTest.test==5)
        {B="SELECT COUNT(*) FROM [test9].[dbo].[six] A, [test9].[dbo].[sixstu] B where (A.ID=B.ID and A.standard_answers5=B.students_answers)";}
	String driverName2 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	String dbURL2 = "jdbc:sqlserver://localhost:1433;DatabaseName=test9";
	String userName2="sa";
	String userPwd2="abcd1234";
	Connection dbConn2=null;
	Statement sta2=null;
	float t = 0;
	try
	{                                                                                       	      
	    Class.forName(driverName2);
            dbConn2 = DriverManager.getConnection(dbURL2,userName2,userPwd2);
	    System.out.println("OK!");
	    sta2=dbConn2.createStatement();
            ResultSet rs1= sta2.executeQuery(B);
	    {
	    	while(rs1.next())
                {
	    	    t=(float)rs1.getInt(1)/TesterFrame6.n;
                }
                System.out.print(t);
	    }//计分功能，若学生答案等于标准答案，得1分，否则不得分
            sta2.close();
	} 
        catch(Exception e)
        {
	    e.printStackTrace();
	    System.out.println("Error!");
	}
	return t;
    }
}

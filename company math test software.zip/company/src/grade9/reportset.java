/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grade9;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import main.Login;
import main.SelectGrade;


/**
 *
 * @author Administrator
 */
public class reportset {
    public static String S;
    public static String report91_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part1','level5')";
        return S;
    }
    public static String report91_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part1','level6')";
        return S;
    }
    public static String report91_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part1','level4')";
        return S;
    }
    public static String report91_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part1','level7')";
        return S;
    }
    public static String report91_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part1','level8')";
        return S;
    }
    public static String report91_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part1','level3')";
        return S;
    }
    public static String report91_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part1','level1')";
        return S;
    }
    public static String report91_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part1','level2')";
        return S;
    }
    //grade9 part1 report
     public static String report92_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part2','level1')";
        return S;
    }
    public static String report92_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part2','level2')";
        return S;
    }
    public static String report92_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part2','level3')";
        return S;
    }
    public static String report92_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part2','level4')";
        return S;
    }
    public static String report92_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part2','level5')";
        return S;
    }
    public static String report92_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part2','level6')";
        return S;
    }
    public static String report92_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part2','level7')";
        return S;
    }
    public static String report92_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part2','level8')";
        return S;
    }
    //grade9 part2 report
     public static String report93_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part3','level1')";
        return S;
    }
    public static String report93_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part3','level2')";
        return S;
    }
    public static String report93_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part3','level3')";
        return S;
    }
    public static String report93_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part3','level4')";
        return S;
    }
    public static String report93_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part3','level5')";
        return S;
    }
    public static String report93_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part3','level6')";
        return S;
    }
    public static String report93_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part3','level7')";
        return S;
    }
    public static String report93_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part3','level8')";
        return S;
    }
    //grade9 part3 report
     public static String report94_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part4','level1')";
        return S;
    }
    public static String report94_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part4','level2')";
        return S;
    }
    public static String report94_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part4','level3')";
        return S;
    }
    public static String report94_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part4','level4')";
        return S;
    }
    public static String report94_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part4','level5')";
        return S;
    }
    public static String report94_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part4','level6')";
        return S;
    }
    public static String report94_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part4','level7')";
        return S;
    }
    public static String report94_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part4','level8')";
        return S;
    }
    //grade9 part4 report
     public static String report95_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part5','level1')";
        return S;
    }
    public static String report95_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part5','level2')";
        return S;
    }
    public static String report95_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part5','level3')";
        return S;
    }
    public static String report95_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part5','level4')";
        return S;
    }
    public static String report95_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part5','level5')";
        return S;
    }
    public static String report95_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part5','level6')";
        return S;
    }
    public static String report95_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part5','level7')";
        return S;
    }
    public static String report95_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part5','level8')";
        return S;
    }
    //grade9 part5 report
     public static String report96_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part6','level1')";
        return S;
    }
    public static String report96_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part6','level2')";
        return S;
    }
    public static String report96_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part6','level3')";
        return S;
    }
    public static String report96_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part6','level4')";
        return S;
    }
    public static String report96_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part6','level5')";
        return S;
    }
    public static String report96_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part6','level6')";
        return S;
    }
    public static String report96_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part6','level7')";
        return S;
    }
    public static String report96_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part6','level8')";
        return S;
    }
    //grade9 part6 report
    public static String report97_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part7','level1')";
        return S;
    }
    public static String report97_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part7','level2')";
        return S;
    }
    public static String report97_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part7','level3')";
        return S;
    }
    public static String report97_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part7','level4')";
        return S;
    }
    public static String report97_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part7','level5')";
        return S;
    }
    public static String report97_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part7','level6')";
        return S;
    }
    public static String report97_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part7','level7')";
        return S;
    }
    public static String report97_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade9','Part7','level8')";
        return S;
    }
    //grade9 part7 report
    
    public static void OK()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=information";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(S);
	    sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
        System.out.print(S);
    } 
}

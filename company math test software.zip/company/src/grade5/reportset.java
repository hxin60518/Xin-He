/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grade5;




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import main.Login;
import main.SelectGrade;


/**
 *
 * @author Administrator
 */
public class reportset {
    public static String S;
    public static String report51_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part1','level5')";
        return S;
    }
    public static String report51_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part1','level6')";
        return S;
    }
    public static String report51_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part1','level4')";
        return S;
    }
    public static String report51_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part1','level7')";
        return S;
    }
    public static String report51_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part1','level8')";
        return S;
    }
    public static String report51_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part1','level3')";
        return S;
    }
    public static String report51_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part1','level1')";
        return S;
    }
    public static String report51_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part1','level2')";
        return S;
    }
    //grade5 part1 report
     public static String report52_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part2','level1')";
        return S;
    }
    public static String report52_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part2','level2')";
        return S;
    }
    public static String report52_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part2','level3')";
        return S;
    }
    public static String report52_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part2','level4')";
        return S;
    }
    public static String report52_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part2','level5')";
        return S;
    }
    public static String report52_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part2','level6')";
        return S;
    }
    public static String report52_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part2','level7')";
        return S;
    }
    public static String report52_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part2','level8')";
        return S;
    }
    //grade5 part2 report
     public static String report53_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part3','level1')";
        return S;
    }
    public static String report53_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part3','level2')";
        return S;
    }
    public static String report53_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part3','level3')";
        return S;
    }
    public static String report53_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part3','level4')";
        return S;
    }
    public static String report53_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part3','level5')";
        return S;
    }
    public static String report53_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part3','level6')";
        return S;
    }
    public static String report53_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part3','level7')";
        return S;
    }
    public static String report53_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part3','level8')";
        return S;
    }
    //grade5 part3 report
     public static String report54_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part4','level1')";
        return S;
    }
    public static String report54_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part4','level2')";
        return S;
    }
    public static String report54_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part4','level3')";
        return S;
    }
    public static String report54_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part4','level4')";
        return S;
    }
    public static String report54_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part4','level5')";
        return S;
    }
    public static String report54_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part4','level6')";
        return S;
    }
    public static String report54_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part4','level7')";
        return S;
    }
    public static String report54_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part4','level8')";
        return S;
    }
    //grade5 part4 report
     public static String report55_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part5','level1')";
        return S;
    }
    public static String report55_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part5','level2')";
        return S;
    }
    public static String report55_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part5','level3')";
        return S;
    }
    public static String report55_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part5','level4')";
        return S;
    }
    public static String report55_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part5','level5')";
        return S;
    }
    public static String report55_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part5','level6')";
        return S;
    }
    public static String report55_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part5','level7')";
        return S;
    }
    public static String report55_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part5','level8')";
        return S;
    }
    //grade5 part5 report
     public static String report56_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part6','level1')";
        return S;
    }
    public static String report56_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part6','level2')";
        return S;
    }
    public static String report56_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part6','level3')";
        return S;
    }
    public static String report56_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part6','level4')";
        return S;
    }
    public static String report56_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part6','level5')";
        return S;
    }
    public static String report56_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part6','level6')";
        return S;
    }
    public static String report56_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part6','level7')";
        return S;
    }
    public static String report56_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade5','Part6','level8')";
        return S;
    }
    //grade5 part6 report
   
    public static void OK()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=information";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(S);
	    sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
        System.out.print(S);
    } 
}

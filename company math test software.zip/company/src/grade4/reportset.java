/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grade4;





import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import main.Login;
import main.SelectGrade;


/**
 *
 * @author Administrator
 */
public class reportset {
    public static String S;
    public static String report41_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part1','level5')";
        return S;
    }
    public static String report41_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part1','level6')";
        return S;
    }
    public static String report41_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part1','level4')";
        return S;
    }
    public static String report41_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part1','level7')";
        return S;
    }
    public static String report41_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part1','level8')";
        return S;
    }
    public static String report41_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part1','level3')";
        return S;
    }
    public static String report41_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part1','level1')";
        return S;
    }
    public static String report41_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part1','level2')";
        return S;
    }
    //grade4 part1 report
     public static String report42_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part2','level1')";
        return S;
    }
    public static String report42_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part2','level2')";
        return S;
    }
    public static String report42_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part2','level3')";
        return S;
    }
    public static String report42_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part2','level4')";
        return S;
    }
    public static String report42_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part2','level5')";
        return S;
    }
    public static String report42_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part2','level6')";
        return S;
    }
    public static String report42_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part2','level7')";
        return S;
    }
    public static String report42_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part2','level8')";
        return S;
    }
    //grade4 part2 report
     public static String report43_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part3','level1')";
        return S;
    }
    public static String report43_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part3','level2')";
        return S;
    }
    public static String report43_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part3','level3')";
        return S;
    }
    public static String report43_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part3','level4')";
        return S;
    }
    public static String report43_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part3','level5')";
        return S;
    }
    public static String report43_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part3','level6')";
        return S;
    }
    public static String report43_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part3','level7')";
        return S;
    }
    public static String report43_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part3','level8')";
        return S;
    }
    //grade4 part3 report
     public static String report44_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part4','level1')";
        return S;
    }
    public static String report44_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part4','level2')";
        return S;
    }
    public static String report44_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part4','level3')";
        return S;
    }
    public static String report44_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part4','level4')";
        return S;
    }
    public static String report44_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part4','level5')";
        return S;
    }
    public static String report44_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part4','level6')";
        return S;
    }
    public static String report44_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part4','level7')";
        return S;
    }
    public static String report44_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part4','level8')";
        return S;
    }
    //grade4 part4 report
     public static String report45_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part5','level1')";
        return S;
    }
    public static String report45_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part5','level2')";
        return S;
    }
    public static String report45_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part5','level3')";
        return S;
    }
    public static String report45_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part5','level4')";
        return S;
    }
    public static String report45_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part5','level5')";
        return S;
    }
    public static String report45_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part5','level6')";
        return S;
    }
    public static String report45_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part5','level7')";
        return S;
    }
    public static String report45_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part5','level8')";
        return S;
    }
    //grade4 part5 report
     public static String report46_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part6','level1')";
        return S;
    }
    public static String report46_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part6','level2')";
        return S;
    }
    public static String report46_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part6','level3')";
        return S;
    }
    public static String report46_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part6','level4')";
        return S;
    }
    public static String report46_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part6','level5')";
        return S;
    }
    public static String report46_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part6','level6')";
        return S;
    }
    public static String report46_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part6','level7')";
        return S;
    }
    public static String report46_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade4','Part6','level8')";
        return S;
    }
    //grade4 part6 report
   
    public static void OK()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=information";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(S);
	    sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
        System.out.print(S);
    } 
}

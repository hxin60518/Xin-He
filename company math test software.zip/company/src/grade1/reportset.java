/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grade1;







import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import main.Login;
import main.SelectGrade;


/**
 *
 * @author Administrator
 */
public class reportset {
    public static String S;
    public static String report11_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part1','level5')";
        return S;
    }
    public static String report11_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part1','level6')";
        return S;
    }
    public static String report11_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part1','level4')";
        return S;
    }
    public static String report11_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part1','level7')";
        return S;
    }
    public static String report11_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part1','level8')";
        return S;
    }
    public static String report11_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part1','level3')";
        return S;
    }
    public static String report11_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part1','level1')";
        return S;
    }
    public static String report11_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part1','level2')";
        return S;
    }
    //grade1 part1 report
     public static String report12_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part2','level1')";
        return S;
    }
    public static String report12_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part2','level2')";
        return S;
    }
    public static String report12_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part2','level3')";
        return S;
    }
    public static String report12_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part2','level4')";
        return S;
    }
    public static String report12_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part2','level5')";
        return S;
    }
    public static String report12_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part2','level6')";
        return S;
    }
    public static String report12_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part2','level7')";
        return S;
    }
    public static String report12_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part2','level8')";
        return S;
    }
    //grade1 part2 report
     public static String report13_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part3','level1')";
        return S;
    }
    public static String report13_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part3','level2')";
        return S;
    }
    public static String report13_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part3','level3')";
        return S;
    }
    public static String report13_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part3','level4')";
        return S;
    }
    public static String report13_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part3','level5')";
        return S;
    }
    public static String report13_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part3','level6')";
        return S;
    }
    public static String report13_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part3','level7')";
        return S;
    }
    public static String report13_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part3','level8')";
        return S;
    }
    //grade1 part3 report
     public static String report14_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part4','level1')";
        return S;
    }
    public static String report14_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part4','level2')";
        return S;
    }
    public static String report14_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part4','level3')";
        return S;
    }
    public static String report14_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part4','level4')";
        return S;
    }
    public static String report14_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part4','level5')";
        return S;
    }
    public static String report14_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part4','level6')";
        return S;
    }
    public static String report14_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part4','level7')";
        return S;
    }
    public static String report14_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part4','level8')";
        return S;
    }
    //grade1 part4 report
     public static String report15_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part5','level1')";
        return S;
    }
    public static String report15_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part5','level2')";
        return S;
    }
    public static String report15_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part5','level3')";
        return S;
    }
    public static String report15_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part5','level4')";
        return S;
    }
    public static String report15_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part5','level5')";
        return S;
    }
    public static String report15_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part5','level6')";
        return S;
    }
    public static String report15_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part5','level7')";
        return S;
    }
    public static String report15_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part5','level8')";
        return S;
    }
    //grade1 part5 report
     public static String report16_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part6','level1')";
        return S;
    }
    public static String report16_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part6','level2')";
        return S;
    }
    public static String report16_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part6','level3')";
        return S;
    }
    public static String report16_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part6','level4')";
        return S;
    }
    public static String report16_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part6','level5')";
        return S;
    }
    public static String report16_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part6','level6')";
        return S;
    }
    public static String report16_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part6','level7')";
        return S;
    }
    public static String report16_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade1','Part6','level8')";
        return S;
    }
    //grade1 part6 report
   
    public static void OK()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=information";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(S);
	    sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
        System.out.print(S);
    } 
}

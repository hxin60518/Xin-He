/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grade8;


import main.SelectTest;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import main.Login;
import main.SelectGrade;


/**
 *
 * @author Administrator
 */
public class reportset {
    public static String S;
    public static String report81_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part1','level1')";
        return S;
    }
    public static String report81_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part1','level2')";
        return S;
    }
    public static String report81_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part1','level5')";
        return S;
    }
    public static String report81_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part1','level6')";
        return S;
    }
    public static String report81_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part1','level4')";
        return S;
    }
    public static String report81_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part1','level7')";
        return S;
    }
    public static String report81_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part1','level8')";
        return S;
    }
    public static String report81_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part1','level3')";
        return S;
    }
    //grade8 part1 report
    public static String report82_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part2','level1')";
        return S;
    }
    public static String report82_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part2','level2')";
        return S;
    }
    public static String report82_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part2','level3')";
        return S;
    }
    public static String report82_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part2','level4')";
        return S;
    }
    public static String report82_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part2','level5')";
        return S;
    }
    public static String report82_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part2','level6')";
        return S;
    }
    public static String report82_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part2','level7')";
        return S;
    }
    public static String report82_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part2','level8')";
        return S;
    }
    //grade8 part2 report
    public static String report83_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part3','level1')";
        return S;
    }
    public static String report83_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part3','level2')";
        return S;
    }
    public static String report83_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part3','level3')";
        return S;
    }
    public static String report83_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part3','level4')";
        return S;
    }
    public static String report83_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part3','level5')";
        return S;
    }
    public static String report83_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part3','level6')";
        return S;
    }
    public static String report83_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part3','level7')";
        return S;
    }
    public static String report83_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part3','level8')";
        return S;
    }
    //grade8 part3 report
    public static String report84_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part4','level1')";
        return S;
    }
    public static String report84_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part4','level2')";
        return S;
    }
    public static String report84_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part4','level3')";
        return S;
    }
    public static String report84_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part4','level4')";
        return S;
    }
    public static String report84_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part4','level5')";
        return S;
    }
    public static String report84_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part4','level6')";
        return S;
    }
    public static String report84_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part4','level7')";
        return S;
    }
    public static String report84_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part4','level8')";
        return S;
    }
    //grade8 part4 report
    public static String report85_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part5','level1')";
        return S;
    }
    public static String report85_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part5','level2')";
        return S;
    }
    public static String report85_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part5','level3')";
        return S;
    }
    public static String report85_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part5','level4')";
        return S;
    }
    public static String report85_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part5','level5')";
        return S;
    }
    public static String report85_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part5','level6')";
        return S;
    }
    public static String report85_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part5','level7')";
        return S;
    }
    public static String report85_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part5','level8')";
        return S;
    }
    //grade8 part5 report
    public static String report86_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part6','level1')";
        return S;
    }
    public static String report86_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part6','level2')";
        return S;
    }
    public static String report86_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part6','level3')";
        return S;
    }
    public static String report86_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part6','level4')";
        return S;
    }
    public static String report86_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part6','level5')";
        return S;
    }
    public static String report86_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part6','level6')";
        return S;
    }
    public static String report86_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part6','level7')";
        return S;
    }
    public static String report86_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part6','level8')";
        return S;
    }
    //grade8 part6 report
   public static String report87_1()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part7','level1')";
        return S;
    }
    public static String report87_2()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part7','level2')";
        return S;
    }
    public static String report87_3()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part7','level3')";
        return S;
    }
    public static String report87_4()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part7','level4')";
        return S;
    }
    public static String report87_5()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part7','level5')";
        return S;
    }
    public static String report87_6()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part7','level6')";
        return S;
    }
    public static String report87_7()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part7','level7')";
        return S;
    }
    public static String report87_8()
    {
        S="INSERT INTO report (test_date,test_number,students_id,name,actual_grade,test_grade,test_part,students_report)" +"VALUES (getdate(),'"+main.SelectTest.test+"','"+Login.ID+"','"+SelectGrade.name+"','"+SelectGrade.G+"','grade8','Part7','level8')";
        return S;
    }
    //grade8 part7 report
    
    public static void OK()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=information";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(S);
	    sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
        System.out.print(S);
    } 
}

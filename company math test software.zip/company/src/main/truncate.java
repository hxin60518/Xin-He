package main;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
/**
 *
 * @author Administrator
 */
public class truncate {
    public static String A,B,C,D,E,F,G;
    public static void students()
    {
        A="truncate table onestu";
        B="truncate table twostu";
        C="truncate table threestu";
        D="truncate table fourstu";
        E="truncate table fivestu";
        F="truncate table sixstu";
        G="TRUNCATE table sevenstu";
    }
    public static void OK1()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=test1";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(A);
            sta1.executeUpdate(B);
            sta1.executeUpdate(C);
            sta1.executeUpdate(D);
            sta1.executeUpdate(E);
            sta1.executeUpdate(F);
            sta1.executeUpdate(G);
	    sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
    }
    //test1 clear
    public static void OK2()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=test2";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(A);
            sta1.executeUpdate(B);
            sta1.executeUpdate(C);
            sta1.executeUpdate(D);
            sta1.executeUpdate(E);
            sta1.executeUpdate(F);
            sta1.executeUpdate(G);
            sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
    }//test2 clear
    
    public static void OK3()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=test3";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(A);
            sta1.executeUpdate(B);
            sta1.executeUpdate(C);
            sta1.executeUpdate(D);
            sta1.executeUpdate(E);
            sta1.executeUpdate(F);
            sta1.executeUpdate(G);
            sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
    }//test3 clear
    
    public static void OK4()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=test4";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(A);
            sta1.executeUpdate(B);
            sta1.executeUpdate(C);
            sta1.executeUpdate(D);
            sta1.executeUpdate(E);
            sta1.executeUpdate(F);
            sta1.executeUpdate(G);
            sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
    }//test4 clear
    
    public static void OK5()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=test5";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(A);
            sta1.executeUpdate(B);
            sta1.executeUpdate(C);
            sta1.executeUpdate(D);
            sta1.executeUpdate(E);
            sta1.executeUpdate(F);
            sta1.executeUpdate(G);
            sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
    }//test5 clear
    
    public static void OK6()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=test6";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(A);
            sta1.executeUpdate(B);
            sta1.executeUpdate(C);
            sta1.executeUpdate(D);
            sta1.executeUpdate(E);
            sta1.executeUpdate(F);
            sta1.executeUpdate(G);
            sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
    }//test6 clear
    
    public static void OK7()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=test7";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(A);
            sta1.executeUpdate(B);
            sta1.executeUpdate(C);
            sta1.executeUpdate(D);
            sta1.executeUpdate(E);
            sta1.executeUpdate(F);
            sta1.executeUpdate(G);
            sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
    }//test7 clear
    
    public static void OK8()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=test8";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(A);
            sta1.executeUpdate(B);
            sta1.executeUpdate(C);
            sta1.executeUpdate(D);
            sta1.executeUpdate(E);
            sta1.executeUpdate(F);
            sta1.executeUpdate(G);
            sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
    }//test8 clear
    
    public static void OK9()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=test9";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(A);
            sta1.executeUpdate(B);
            sta1.executeUpdate(C);
            sta1.executeUpdate(D);
            sta1.executeUpdate(E);
            sta1.executeUpdate(F);
            sta1.executeUpdate(G);
            sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
    }//test9 clear
    
    public static void OK10()
    {
          String driverName1 = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
	  String dbURL1 = "jdbc:sqlserver://localhost:1433;DatabaseName=test10";
	  String userName1="sa";
	  String userPwd1="abcd1234";
	  Connection dbConn1=null;
	  Statement sta1=null;
	  try
	  {                                                                                       	      
	    Class.forName(driverName1);
	    dbConn1 = DriverManager.getConnection(dbURL1,userName1,userPwd1);
	    sta1=dbConn1.createStatement(); 
            sta1.executeUpdate(A);
            sta1.executeUpdate(B);
            sta1.executeUpdate(C);
            sta1.executeUpdate(D);
            sta1.executeUpdate(E);
            sta1.executeUpdate(F);
            sta1.executeUpdate(G);
            sta1.close();//关闭数据库�
          }
          catch(Exception e)
          {
            e.printStackTrace();
	    System.out.println("Error!");
          }
    }//test10 clear
}

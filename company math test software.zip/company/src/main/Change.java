/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package main;

/**
 *
 * @author Administrator
 */
public class Change {
    public static void part1()
    {
       if(main.SelectGrade.G==1)
       {
           grade1.Part1 a=new grade1.Part1();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==2)
       {
           grade2.Part1 a=new grade2.Part1();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==3)
       {
           grade3.Part1 a=new grade3.Part1();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==4)
       {
           grade4.Part1 a=new grade4.Part1();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==5)
       {
           grade5.Part1 a=new grade5.Part1();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==6)
       {
           grade6.Part1 a=new grade6.Part1();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==7)
       {
           grade7.Part1 a=new grade7.Part1();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==8)
       {
           grade8.Part1 a=new grade8.Part1();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==9)
       {   
           grade9.Part1 a=new grade9.Part1();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==10)
       {
           grade10.Part1 a=new grade10.Part1();
           a.setVisible(true);
       }
    }
    public static void part2()
    {
       if(main.SelectGrade.G==1)
       {
           grade1.Part2 a=new grade1.Part2();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==2)
       {
           grade2.Part2 a=new grade2.Part2();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==3)
       {
           grade3.Part2 a=new grade3.Part2();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==4)
       {
           grade4.Part2 a=new grade4.Part2();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==5)
       {
           grade5.Part2 a=new grade5.Part2();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==6)
       {
           grade6.Part2 a=new grade6.Part2();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==7)
       {
           grade7.Part2 a=new grade7.Part2();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==8)
       {
           grade8.Part2 a=new grade8.Part2();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==9)
       {   
           grade9.Part2 a=new grade9.Part2();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==10)
       {
           grade10.Part2 a=new grade10.Part2();
           a.setVisible(true);
       }
    }
    public static void part3()
    {
       if(main.SelectGrade.G==1)
       {
           grade1.Part3 a=new grade1.Part3();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==2)
       {
           grade2.Part3 a=new grade2.Part3();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==3)
       {
           grade3.Part3 a=new grade3.Part3();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==4)
       {
           grade4.Part3 a=new grade4.Part3();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==5)
       {
           grade5.Part3 a=new grade5.Part3();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==6)
       {
           grade6.Part3 a=new grade6.Part3();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==7)
       {
           grade7.Part3 a=new grade7.Part3();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==8)
       {
           grade8.Part3 a=new grade8.Part3();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==9)
       {   
           grade9.Part3 a=new grade9.Part3();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==10)
       {
           grade10.Part3 a=new grade10.Part3();
           a.setVisible(true);
       }
    }
    public static void part4()
    {
       if(main.SelectGrade.G==1)
       {
           grade1.Part4 a=new grade1.Part4();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==2)
       {
           grade2.Part4 a=new grade2.Part4();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==3)
       {
           grade3.Part4 a=new grade3.Part4();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==4)
       {
           grade4.Part4 a=new grade4.Part4();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==5)
       {
           grade5.Part4 a=new grade5.Part4();
           a.setVisible(true);
       } 
        else if(main.SelectGrade.G==8)
       {
           grade8.Part4 a=new grade8.Part4();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==9)
       {   
           grade9.Part4 a=new grade9.Part4();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==10)
       {
           grade10.Part4 a=new grade10.Part4();
           a.setVisible(true);
       }
    }
    public static void part5()
    {
        if(main.SelectGrade.G==1)
       {
           grade1.Part5 a=new grade1.Part5();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==2)
       {
           grade2.Part5 a=new grade2.Part5();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==3)
       {
           grade3.Part5 a=new grade3.Part5();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==4)
       {
           grade4.Part5 a=new grade4.Part5();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==5)
       {
           grade5.Part5 a=new grade5.Part5();
           a.setVisible(true);
       } 
        else if(main.SelectGrade.G==10)
       {
           grade10.Part5 a=new grade10.Part5();
           a.setVisible(true);
       }
    }
    public static void part6()
    {
        if(main.SelectGrade.G==1)
       {
           grade1.Part6 a=new grade1.Part6();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==2)
       {
           grade2.Part6 a=new grade2.Part6();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==3)
       {
           grade3.Part6 a=new grade3.Part6();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==4)
       {
           grade4.Part6 a=new grade4.Part6();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==5)
       {
           grade5.Part6 a=new grade5.Part6();
           a.setVisible(true);
       } 
        else if(main.SelectGrade.G==6)
       {
           grade6.Part6 a=new grade6.Part6();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==9)
       {   
           grade9.Part6 a=new grade9.Part6();
           a.setVisible(true);
       }
    }
    public static void part7()
    {
       if(main.SelectGrade.G==6)
       {
           grade6.Part7 a=new grade6.Part7();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==7)
       {
           grade7.Part7 a=new grade7.Part7();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==8)
       {
           grade8.Part7 a=new grade8.Part7();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==9)
       {   
           grade9.Part7 a=new grade9.Part7();
           a.setVisible(true);
       }
       else if(main.SelectGrade.G==10)
       {
           grade10.Part7 a=new grade10.Part7();
           a.setVisible(true);
       }
    }
    public static void close()
    {
        report_exit exit=new report_exit();
        exit.setVisible(true);
    }
}

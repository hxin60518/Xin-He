package main;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.swing.ImageIcon;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

/**
 *
 * @author Administrator
 */
public class showpicture extends javax.swing.JPanel {
    public static String pdfFileName;
    private int width = 0;  
    private int height = 0;  
    Image image;  
  
    public showpicture(int _width, int _height, Image _image) {  
        width = _width;  
        height = _height;  
        image = _image;  
        setSize(width, height);  
        setVisible(true);  
    }  
    
    @Override  
    public void paintComponent(Graphics gs) {  
        Graphics2D g = (Graphics2D) gs;  
        super.paintComponent(g);  
        g.drawImage(image, 0, 0, width, height, this);  
    }  
    
    public static Image pdfToImg(String pdfFileName) {  
        ImageIcon imageIcon = null;  
        try {  
            PDDocument doc = PDDocument.load(pdfFileName);  
            int pageCount = doc.getNumberOfPages();  
            System.out.println(pageCount);  
            PDPage page = (PDPage) doc.getDocumentCatalog().getAllPages().get(0);  
            BufferedImage bufferedImage = page.convertToImage();  
            if (bufferedImage != null) {  
                imageIcon = new ImageIcon(Toolkit.getDefaultToolkit().createImage(bufferedImage.getSource()));  
            }  
            doc.close();  
        } catch (IOException e) {  
           e.printStackTrace();   
        }  
        return imageIcon.getImage();  
    }
}
